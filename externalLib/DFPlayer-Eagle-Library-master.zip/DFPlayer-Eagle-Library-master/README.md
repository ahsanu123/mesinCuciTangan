# DFPlayer-Eagle-Library
Eagle Cad Library for [DFPlayer Mini SKU:DFR0299](http://www.dfrobot.com/wiki/index.php/DFPlayer_Mini_SKU:DFR0299)

![alt tag](https://github.com/inflop/DFPlayer-Eagle-Library/blob/master/symbol.png)
![alt tag](https://github.com/inflop/DFPlayer-Eagle-Library/blob/master/package.png)
